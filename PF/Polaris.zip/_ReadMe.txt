-----------------------------------------------------------------------------------------------------------------------
------> INFO
-----------------------------------------------------------------------------------------------------------------------

Template Name: Polaris
Design/Development: templatefoundation.com
License: Free for personal and commercial use under the Creative Commons Attribution 4.0 license


-----------------------------------------------------------------------------------------------------------------------
------> CREDITS
-----------------------------------------------------------------------------------------------------------------------

- jQuery ( https://jquery.com/ )
- Bootstrap ( http://getbootstrap.com/ )
- Featherlight ( https://noelboss.github.io/featherlight/ )
- SmoothScroll For Websites ( https://github.com/galambalazs/smoothscroll-for-websites )
- jQuery One Page Nav ( http://github.com/davist11/jQuery-One-Page-Nav )
- Google Font Open Sans ( https://fonts.google.com/specimen/Open+Sans )
- Font Awesome ( http://fontawesome.io/ )
- Demo Images ( https://pixabay.com/ https://www.pexels.com/ )